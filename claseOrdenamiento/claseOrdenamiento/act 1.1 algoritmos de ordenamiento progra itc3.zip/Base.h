#pragma once
#include <iostream>

using namespace std;
#define RANDMAX 20

class Base {
public:
	Base() {
		tamano = tamano;
	}
	~Base() {
		if (arreglo) {
			delete[] arreglo;
			arreglo = nullptr;
		}
	}

	void iniciarArreglo();
	void setSize(int nuevoSize);
	void imprimirArreglo();
	void bubbleSort();
	void insertionSort();
	void selectionSort();
	void mergeSortear();
	void mergeSort(int inicio, int fin);
	void mezclar(int izquierda, int mitad, int derecha);

private:
	int* arreglo= nullptr;;
	int tamano;
};
