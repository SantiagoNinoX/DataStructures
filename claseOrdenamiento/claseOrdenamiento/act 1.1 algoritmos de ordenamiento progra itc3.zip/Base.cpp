#include <iostream>
#include <ctime>
#include "Base.h"

void Base::iniciarArreglo() {
	if (arreglo) {     //Por si quedaron datos.
		delete[] arreglo;
		arreglo = nullptr;
	}
	arreglo = new(nothrow) int[tamano];
	if (!arreglo) {
		cout << "No hay memoria disponible en el heap" << endl;
		return;
	}
	srand(time(0));
	for (int i = 0; i < tamano; i++) {
		arreglo[i] = rand() % 100;
	}
}

void Base::setSize(int nuevoSize) {
	this->tamano = nuevoSize;
	if (arreglo) {
		delete[] arreglo;
		arreglo = nullptr;
	}
	arreglo = new (nothrow) int[tamano];
}

void Base::imprimirArreglo() {
	for (int i = 0; i < tamano; i++) {
		cout << arreglo[i] << " ";
	}
	cout << endl;
}

void Base::bubbleSort() {
	for (int j = 0; j < tamano-1; j++) {
		for (int i = 0; i < tamano-1-j; i++) {
			if (arreglo[i] > arreglo[i + 1]) {
				int temp = arreglo[i];
				arreglo[i] = arreglo[i + 1];
				arreglo[i + 1] = temp;
			}
		}
	}
}

void Base::insertionSort() {
	for (int i = 1; i < tamano; i++) {
		int temp = arreglo[i];
		int j = i - 1;
		while (j >= 0 && temp < arreglo[j]) {
			arreglo[j+1] = arreglo[j];
			j = j - 1;
		}
		arreglo[j+1] = temp;
	}
}

void Base::selectionSort() {
	for (int i = 0; i < tamano; i++) {
		int posicionMini = i;
		for (int j = i + 1; j < tamano; j++) {
			if (arreglo[j] < arreglo[posicionMini]) {
				posicionMini = j;
			}
		}
		if (posicionMini != i) {
			int act = arreglo[i];
			arreglo[i] = arreglo[posicionMini];
			arreglo[posicionMini] = act;
		}
	}
}

void Base::mergeSortear() {
	mergeSort(0, tamano - 1);
}

void Base::mergeSort(int inicio, int fin) {
	int mitad = 0;
	if (inicio >= fin) {
		return;
	}
	mitad = inicio + (fin - inicio) / 2;
	
	mergeSort(inicio, mitad);
	mergeSort(mitad + 1, fin);
	mezclar(inicio, mitad, fin);
}

void Base::mezclar(int izquierda, int mitad, int derecha) {
	int tama�oIzq, tama�oDer;
	tama�oIzq = mitad - izquierda + 1;
	tama�oDer = derecha - mitad;

	int* arrIzq = nullptr;
	int* arrDer = nullptr;

	arrIzq = new(nothrow) int[tama�oIzq];
	if (!arrIzq) {
		cout << "No hay memoria para los sub-arreglos" << endl;
		delete[] arrIzq;
		return;
	}

	arrDer = new(nothrow) int[tama�oDer];
	if (!arrDer) {
		cout << "No hay memoria para los sub-arreglos" << endl;
		delete[] arrDer;
		return;
	}

	for (int i = 0; i < tama�oIzq; i++) {
		arrIzq[i] = arreglo[izquierda + i];
	}
	for (int j = 0; j < tama�oDer; j++) {
		arrDer[j] = arreglo[mitad + 1 + j];
	}
	int i = 0, j = 0, k = izquierda;

	while (i < tama�oIzq && j < tama�oDer) {
		if (arrIzq[i] <= arrDer[j]) {
			arreglo[k] = arrIzq[i];
			i++;
		}
		else {
			arreglo[k] = arrDer[j];
			j++;
		}
		k++;
	}
	while (i < tama�oIzq) {
		arreglo[k] = arrIzq[i];
		i++;
		k++;
	}
	while (j < tama�oDer) {
		arreglo[k] = arrDer[j];
		j++;
		k++;
	}
	if (arrIzq && arrDer) {
		delete[] arrIzq;
		arrIzq = nullptr;
		delete[] arrDer;
		arrDer = nullptr;
	}
}